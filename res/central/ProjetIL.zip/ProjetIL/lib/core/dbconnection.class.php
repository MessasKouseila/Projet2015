
<?php


class dbconnection
{
  private $link, $error ;

  public function __construct()
  {
    $this->link = null;
    $this->error = null;
    try{
        $this->link = new PDO('pgsql:dbname=etd;host=localhost', 'uapv1600543', 'GgIE85');

    }catch( PDOException $e ){
        $this->error =  $e->getMessage();
    }
  }

  public function getLastInsertId($att)
  {
    return $this->link->lastInsertId($att."_id_seq");
  }

  public function doExec( $sql )
  {
    $prepared = $this->link->prepare($sql);
    return $prepared->execute();
  }

  public function doQuery( $sql )
  {
    $prepared = $this->link->prepare( $sql );
    $prepared->execute();
    $res = $prepared->fetchAll( PDO::FETCH_ASSOC );
   
    return $res;
  }

  public function doQueryObject( $sql, $className )
  {
    $prepared = $this->link->prepare( $sql );
    $prepared->execute();
    $res = $prepared->fetchAll( PDO::FETCH_CLASS, $className );
   
    return $res;
  }

  public function doQueryObjectOne( $sql, $className )
  {
    $prepared = $this->link->prepare( $sql );
    $prepared->execute();
    $prepared->setFetchMode(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, $className);
    $res = $prepared->fetch();
   
    return $res;
  }

  public function count( $sql )
  {
    $prepared = $this->link->prepare( $sql );
    $prepared->execute();
    $res = $prepared->fetchColumn();
    return $res;
  }

  public function __destruct()
  {
    $this->link = null;
  }
}
