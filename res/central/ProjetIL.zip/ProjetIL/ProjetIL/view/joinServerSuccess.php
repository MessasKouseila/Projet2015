<div class="waitting"><?=$context->waitting?></div>
<?php if($context->waitting != 1 ){?>
	<?php foreach ($context->ip as $server) {?>
		<div class="ipServer"><?=$server->id?></div>
	<?php }?>
	
<?php } ?>