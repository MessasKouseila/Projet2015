<?php 
$classement = 1;
//var_dump($context->req);
echo '<table id="stats">';
foreach($context->req as $data){?>
 <tr>
    <td class="player"><?=$data->player?></td>
    <td class="elo"><?=$data->elo?></td>
    <td class="classement"><?=$classement++?></td>
    <td class="gagnee"><?=$data->gagnee?></td>
    <td class="perdue"><?=$data->perdue?></td>
    <td class="nbrpartie"><?=$data->nbrpartie?></td>
    <td class="moyenne"><?=$data->moyenne?></td>
  </tr>
<?php }?>
</table> 

