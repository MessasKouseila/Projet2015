<table>
	
	  	<?php foreach ($context->profiles as $key) {?>
		  	<tr>
			    <td class="username"><?= $key->id?></td>
			    <td class="pass"><?= $key->password?></td>
			    <td class="email"><?= $key->email?></td>
			    <td class="country"><?=$key->country?></td>
			    <td class="elo"><?=$key->elo?></td>
			</tr>
		<?php }?>
</table> 