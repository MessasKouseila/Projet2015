<div class="login"><?=$context->login?></div>
<?php if($context->login =="true"){?>
<div class="username"><?=$context->id?></div>
<div class="pass"><?=$context->password?></div>
<div class="email"><?=$context->email?></div>
<div class="country"><?=$context->country?></div>
<div class="elo"><?=$context->elo?></div>
<div class="idPlayer"><?=$context->idPlayer?></div>
<?php } ?>