<div class="delete"><?=$context->delete?></div>
