<?php var_dump($context->date);?>
<div class="exist"><?=$context->exist?></div>
<?php if($context->exist == "true"){?>
	<div class="elo"><?=$context->elo?></div>
	<div class="partieGagnee"><?=$context->partieGagnee?></div>
	<div class="partiePerdu"><?=$context->partiePerdu?></div>
	<div class="partie"><?=$context->partie?></div>
	<div class="classementM"><?=$context->classementM?></div>
	<div class="classementElo"><?=$context->classementElo?></div>
<?php }?>