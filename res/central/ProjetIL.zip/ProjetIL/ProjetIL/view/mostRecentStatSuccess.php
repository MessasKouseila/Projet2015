<div class="date"><?=$context->date?></div>
