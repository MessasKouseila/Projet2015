<?php
/*
 * Controler 
 */

class mainController
{
	public static function displayProfile($request,$context){
		$context->profiles = playerTable::getPlayers();
		return context::SUCCESS;
	}
	public static function signUpServer($request,$context){
			$serveur = new server();
			$serveur->id = $request['id'];
			$serveur->port = $request['port'];
			$serveur->playernumber = $request['playernumber'];
			$serveur->created = date("Y-M-d H:i:s");
			$serveur->updated = date("Y-M-d H:i:s");
			$serveur->completed = $request['completed'];
			if(serverTable::countServers($request['id']) >= 1){
				$serveur->exist = true;
			}else{
				$serveur->exist = false;
			}
			$a = $serveur->save();
	}


	public static function createProfile($request,$context){
		$player = new player();
		$player->id = $request['username'];
		$player->password = $request['password'];
		$player->country = $request['country'];
		$player->elo = $request['elo'];
		$player->email = $request['email'];
		if(playerTable::countPlayers($player->id) >= 1){
				$context->waitting = 0;
				return context::SUCCESS;
			}else{
				$player->exist = false;
				if($player->save() != false){
					$context->waitting = 0;
				}else
				    $context->waitting = 1;
				return context::SUCCESS;
			}
	}


	public static function deleteProfile($request, $context){
		$username = $request['profile'];
		$result = playerTable::deleteProfile($username);
		$context->delete = count($result);
		return context::SUCCESS;
	}


	public static function login($request,$context){
		$player = playerTable::loginPlayer($request['username'],$request['password']);
		
		if(!$player)
			$context->login="false";
		else{
			$context->login="true";
			$context->id = $player->id;
			$context->idPlayer = $player->idPlayer;
			$context->password =  $player->password;
			$context->email =  $player->email;
			$context->country = $player->country;
			$context->elo = $player->elo;
	}
		return context::SUCCESS;
	}

	public static function joinServer($request, $context){
		$server = serverTable::getServerNotCompleted();
		if($server == false){
			$context->waitting = 1;
		}else{
			
			/*
			$server_player = new server_player();
			$server_player->server = $ipServer;
			$server_player->player = $username;

			if(server_playerTable::countPlayerServer($server_player->player) != 1){
				$server_player->exist = false;
				$server_player->save();
				$context->waitting = 0;
			}else{
				$context->waitting = 1;
			}*/
			$context->waitting = 0;
			$context->ip = $server;
		}
		return context::SUCCESS;

	}

	public static function playerServer($request, $context){
		$server_player = new server_player();
		$server_player->server = $request['ipServer'];
		$server_player->player = $request['username'];

		if(server_playerTable::countPlayerServer($server_player->player) != 1){
			$server_player->exist = false;
			$server_player->save();
		}
		die();
	}
	public static function deleteServer($request, $context){
		$ipServer = $request['ipServer'];
		$result = serverTable::deleteServer($ipServer);
		die();
	}

	public static function deletePlayerServer($request, $context){
		$ipServer = $request['ipServer'];
		$username = $request['username'];
		$result = server_playerTable::deletePlayerServer($ipServer,$username);
		die();
	}

	public static function mostOlderStat($request, $context){
		$username = $request['username'];
		$result = partieTable::mostOlderStat($username);
		if(is_null($result->min))
			$context->date = "false";
		else
			$context->date = $result->min;
		return context::SUCCESS;
	}

	public static function mostRecentStat($request, $context){
		$username = $request['username'];
		$result = partieTable::mostRecentStat($username);
		if(is_null($result->max))
			$context->date = "false";
		else
			$context->date = $result->max;
		return context::SUCCESS;
	}

	public static function getStats($request, $context){
		$username = $request['username'];
        $datee = str_replace("%3A", ":", $request['date']);
        $date = date_create($datee);

		$formatDate =  date_format($date,"Y-m-d H:i:s");		

		if(partieTable::getCountPartByPlayer($username)){
			$result = partieTable::getStats($username,$datee);
			$eloByDate = partieTable::getEloByDate($formatDate,$username);
			if($eloByDate==false){
				$elo = partieTable::getEloByPlayerAndRecentDate($username,$datee)->max;
			}else{
				$elo = $eloByDate->elo;
			}
			$elos = partieTable::getElos($datee);
				

			$tab2 = array();
			foreach ($elos as $key => $value) {
				if (!array_key_exists($value->player, $tab2)) {
					$tab2[$value->player]=$value->elo;
					//array_push($tab2,$value->player);
				}
			}
			arsort($tab2);
			$classement =1;
			foreach ($tab2 as $tab){
				if($tab == $elo){
					break;
				}
					
				$classement++;
			}
			$context->date = $datee;
			$context->elo = $elo;
			$context->partieGagnee = $result->gagnee;
			$context->partiePerdu = $result->perdue;
			$context->partie = $result->nbrpartie;
			$context->classementM = number_format($result->avg, 2);
			$context->classementElo = $classement;
			$context->exist = "true";
		}else
		 	$context->exist = "false";
		return context::SUCCESS;
	}

	public static function getUsersStats($request, $context){
		$req = partieTable::getUsersStats();
		$context->req = $req;
		return context::SUCCESS;	
	}

	public static function insertStats($request, $context){

		switch ($request['nbrPlayer']) {
			case '2':
				$nomPlayer1   = split(" ",$request['player1'])[0];
				$nomPlayer2   = split(" ",$request['player2'])[0];
				$pointPartiePlayer1 = floatval(split(" ",$request['player1'])[1]);
				$pointPartiePlayer2 = floatval(split(" ",$request['player2'])[1]);
				$pointEloPlayer1 = playerTable::getEloById($nomPlayer1)->elo; 
				$pointEloPlayer2 = playerTable::getEloById($nomPlayer2)->elo;

				$testElo = array($pointEloPlayer1,$pointEloPlayer2);
				$testPts = array($pointPartiePlayer1,$pointPartiePlayer2);
				
				$rating = new ratingmulti($testElo, $testPts);
				$newPointEloPlayer1 = intval($rating->_newElo['0']);
				$newPointEloPlayer2 = intval($rating->_newElo['1']);
				
				$player = new player();
				
				$player->id = $nomPlayer1;
				$player->elo = $newPointEloPlayer1;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer2;
				$player->elo = $newPointEloPlayer2;
				$player->exist = true;
				$player->save();

				$partie = new partie();

				
				$partie->player = $nomPlayer1;
				
				$partie->classement = 1;
				$partie->perdu =0;
				$partie->gagnee =1;
				$partie->elo = $newPointEloPlayer1;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer2;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 2;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo =$newPointEloPlayer2;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();


				break;
			case '3':
				$nomPlayer1   = split(" ",$request['player1'])[0];
				$nomPlayer2   = split(" ",$request['player2'])[0];
				$nomPlayer3   = split(" ",$request['player3'])[0];


				$pointPartiePlayer1 = floatval(split(" ",$request['player1'])[1]);
				$pointPartiePlayer2 = floatval(split(" ",$request['player2'])[1]);
				$pointPartiePlayer3 = floatval(split(" ",$request['player3'])[1]);

				$pointEloPlayer1 = playerTable::getEloById($nomPlayer1)->elo; 
				$pointEloPlayer2 = playerTable::getEloById($nomPlayer2)->elo;
				$pointEloPlayer3 = playerTable::getEloById($nomPlayer3)->elo;

				$testElo = array($pointEloPlayer1,$pointEloPlayer2,$pointEloPlayer3);
				$testPts = array($pointPartiePlayer1,$pointPartiePlayer2,$pointPartiePlayer3);
				
				$rating = new ratingmulti($testElo, $testPts);
				$newPointEloPlayer1 = intval($rating->_newElo['0']);
				$newPointEloPlayer2 = intval($rating->_newElo['1']);
				$newPointEloPlayer3 = intval($rating->_newElo['2']);
				
				$player = new player();
				
				$player->id = $nomPlayer1;
				$player->elo = $newPointEloPlayer1;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer2;
				$player->elo = $newPointEloPlayer2;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer3;
				$player->elo = $newPointEloPlayer3;
				$player->exist = true;
				$player->save();

				$partie = new partie();

				$partie->player = $nomPlayer1;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 1;
				$partie->perdu =0;
				$partie->gagnee =1;
				$partie->elo = $newPointEloPlayer1;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer2;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 2;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer2;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer3;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 3;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer3;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->exist = false;
				$partie->save();
				break;
			case '4':
				$nomPlayer1   = split(" ",$request['player1'])[0];
				$nomPlayer2   = split(" ",$request['player2'])[0];
				$nomPlayer3   = split(" ",$request['player3'])[0];
				$nomPlayer4   = split(" ",$request['player4'])[0];

				$pointPartiePlayer1 = floatval(split(" ",$request['player1'])[1]);
				$pointPartiePlayer2 = floatval(split(" ",$request['player2'])[1]);
				$pointPartiePlayer3 = floatval(split(" ",$request['player3'])[1]);
				$pointPartiePlayer4 = floatval(split(" ",$request['player4'])[1]);

				$pointEloPlayer1 = playerTable::getEloById($nomPlayer1)->elo; 
				$pointEloPlayer2 = playerTable::getEloById($nomPlayer2)->elo;
				$pointEloPlayer3 = playerTable::getEloById($nomPlayer3)->elo;
				$pointEloPlayer4 = playerTable::getEloById($nomPlayer4)->elo;

				$testElo = array($pointEloPlayer1,$pointEloPlayer2,$pointEloPlayer3,$pointEloPlayer4);
				$testPts = array($pointPartiePlayer1,$pointPartiePlayer2,$pointPartiePlayer3,$pointPartiePlayer4);
				
				$rating = new ratingmulti($testElo, $testPts);
				$newPointEloPlayer1 = intval($rating->_newElo['0']);
				$newPointEloPlayer2 = intval($rating->_newElo['1']);
				$newPointEloPlayer3 = intval($rating->_newElo['2']);
				$newPointEloPlayer4 = intval($rating->_newElo['3']);
				
				$player = new player();
				
				$player->id = $nomPlayer1;
				$player->elo = $newPointEloPlayer1;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer2;
				$player->elo = $newPointEloPlayer2;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer3;
				$player->elo = $newPointEloPlayer3;
				$player->exist = true;
				$player->save();
				
				$player->id = $nomPlayer4;
				$player->elo = $newPointEloPlayer4;
				$player->exist = true;
				$player->save();

				$partie = new partie();

				$partie->player = $nomPlayer1;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 1;
				$partie->perdu =0;
				$partie->gagnee =1;
				$partie->elo = $newPointEloPlayer1;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer2;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 2;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer2;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer3;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 3;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer3;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer4;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 4;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer4;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();
			break;
			case '5':
				$nomPlayer1   = split(" ",$request['player1'])[0];
				$nomPlayer2   = split(" ",$request['player2'])[0];
				$nomPlayer3   = split(" ",$request['player3'])[0];
				$nomPlayer4   = split(" ",$request['player4'])[0];
				$nomPlayer5   = split(" ",$request['player5'])[0];

				$pointPartiePlayer1 = floatval(split(" ",$request['player1'])[1]);
				$pointPartiePlayer2 = floatval(split(" ",$request['player2'])[1]);
				$pointPartiePlayer3 = floatval(split(" ",$request['player3'])[1]);
				$pointPartiePlayer4 = floatval(split(" ",$request['player4'])[1]);
				$pointPartiePlayer5 = floatval(split(" ",$request['player5'])[1]);

				$pointEloPlayer1 = playerTable::getEloById($nomPlayer1)->elo; 
				$pointEloPlayer2 = playerTable::getEloById($nomPlayer2)->elo;
				$pointEloPlayer3 = playerTable::getEloById($nomPlayer3)->elo;
				$pointEloPlayer4 = playerTable::getEloById($nomPlayer4)->elo;
				$pointEloPlayer5 = playerTable::getEloById($nomPlayer5)->elo;

				$testElo = array($pointEloPlayer1,$pointEloPlayer2,$pointEloPlayer3,$pointEloPlayer4,$pointEloPlayer5);
				$testPts = array($pointPartiePlayer1,$pointPartiePlayer2,$pointPartiePlayer3,$pointPartiePlayer4,$pointPartiePlayer5);
				
				$rating = new ratingmulti($testElo, $testPts);
				$newPointEloPlayer1 = intval($rating->_newElo['0']);
				$newPointEloPlayer2 = intval($rating->_newElo['1']);
				$newPointEloPlayer3 = intval($rating->_newElo['2']);
				$newPointEloPlayer4 = intval($rating->_newElo['3']);
				$newPointEloPlayer5 = intval($rating->_newElo['4']);
				
				$player = new player();
				
				$player->id = $nomPlayer1;
				$player->elo = $newPointEloPlayer1;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer2;
				$player->elo = $newPointEloPlayer2;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer3;
				$player->elo = $newPointEloPlayer3;
				$player->exist = true;
				$player->save();
				
				$player->id = $nomPlayer4;
				$player->elo = $newPointEloPlayer4;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer5;
				$player->elo = $newPointEloPlayer5;
				$player->exist = true;
				$player->save();


			break;
			case '6':
				$nomPlayer1   = split(" ",$request['player1'])[0];
				$nomPlayer2   = split(" ",$request['player2'])[0];
				$nomPlayer3   = split(" ",$request['player3'])[0];
				$nomPlayer4   = split(" ",$request['player4'])[0];
				$nomPlayer5   = split(" ",$request['player5'])[0];
				$nomPlayer6   = split(" ",$request['player6'])[0];

				$pointPartiePlayer1 = floatval(split(" ",$request['player1'])[1]);
				$pointPartiePlayer2 = floatval(split(" ",$request['player2'])[1]);
				$pointPartiePlayer3 = floatval(split(" ",$request['player3'])[1]);
				$pointPartiePlayer4 = floatval(split(" ",$request['player4'])[1]);
				$pointPartiePlayer5 = floatval(split(" ",$request['player5'])[1]);
				$pointPartiePlayer6 = floatval(split(" ",$request['player6'])[1]);

				$pointEloPlayer1 = playerTable::getEloById($nomPlayer1)->elo; 
				$pointEloPlayer2 = playerTable::getEloById($nomPlayer2)->elo;
				$pointEloPlayer3 = playerTable::getEloById($nomPlayer3)->elo;
				$pointEloPlayer4 = playerTable::getEloById($nomPlayer4)->elo;
				$pointEloPlayer5 = playerTable::getEloById($nomPlayer5)->elo;
				$pointEloPlayer6 = playerTable::getEloById($nomPlayer6)->elo;

				$testElo = array($pointEloPlayer1,$pointEloPlayer2,$pointEloPlayer3,$pointEloPlayer4,$pointEloPlayer5,$pointEloPlayer6);
				$testPts = array($pointPartiePlayer1,$pointPartiePlayer2,$pointPartiePlayer3,$pointPartiePlayer4,$pointPartiePlayer5,$pointPartiePlayer6);
				
				$rating = new ratingmulti($testElo, $testPts);
				$newPointEloPlayer1 = intval($rating->_newElo['0']);
				$newPointEloPlayer2 = intval($rating->_newElo['1']);
				$newPointEloPlayer3 = intval($rating->_newElo['2']);
				$newPointEloPlayer4 = intval($rating->_newElo['3']);
				$newPointEloPlayer5 = intval($rating->_newElo['4']);
				$newPointEloPlayer6 = intval($rating->_newElo['5']);
				
				$player = new player();
				
				$player->id = $nomPlayer1;
				$player->elo = $newPointEloPlayer1;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer2;
				$player->elo = $newPointEloPlayer2;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer3;
				$player->elo = $newPointEloPlayer3;
				$player->exist = true;
				$player->save();
				
				$player->id = $nomPlayer4;
				$player->elo = $newPointEloPlayer4;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer5;
				$player->elo = $newPointEloPlayer5;
				$player->exist = true;
				$player->save();

				$player->id = $nomPlayer6;
				$player->elo = $newPointEloPlayer6;
				$player->exist = true;
				$player->save();

				$partie = new partie();

				$partie->player = $nomPlayer1;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 1;
				$partie->perdu =0;
				$partie->gagnee =1;
				$partie->elo = $newPointEloPlayer1;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer2;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 2;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer2;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer3;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 3;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer3;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer4;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 4;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer4;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer5;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 5;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer5;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();

				$partie->player = $nomPlayer6;
				$partie->mortboard = 0;
				$partie->nbrmanches	 = 0;
				$partie->mortsnake = 0;
				$partie->classement = 6;
				$partie->perdu =1;
				$partie->gagnee =0;
				$partie->elo = $newPointEloPlayer6;
				$partie->date = date("Y-m-d H:i:s");$partie->exist = false;
				$partie->save();
			break;	
			default:
				# code...
				break;
		}
		die();
	}

	
}