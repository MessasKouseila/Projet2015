<?php

class server_player extends basemodel{
	
}?>