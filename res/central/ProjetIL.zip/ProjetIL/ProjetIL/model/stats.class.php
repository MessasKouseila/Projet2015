<?php 
	class stats extends basemodel{}?>
