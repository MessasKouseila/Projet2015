<?php

class server_playerTable {
	public static function getPlayers()
	  {
	    $connection = new dbconnection() ;
	    $sql = "select * from player" ;
	     $res = $connection->doQueryObject( $sql,"player" );
		if($res === false)
	      return false;
		return $res;
	  }

	  public static function countPlayerServer($player)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select COUNT(*) from server_player where player ='".$player."'" ;
	     $res = $connection->count( $sql );
		if($res === false)
	      return false;
		return $res;
	  }

	  public static function deletePlayerServer($ipServer,$username){
	    $connection = new dbconnection() ;
	    $sql = "DELETE FROM server_player WHERE (server = '".$ipServer."' and player ='".$username."')";
		$res = $connection->doQuery( $sql );
		if($res === false)
	      return false;
		return $res;
	}
}?>