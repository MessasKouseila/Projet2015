<?php 
	class player extends basemodel{
		/*public function getFournisseur(){
			 return fournisseurTable::getFournisseurById($this->fournisseur);
  		}*/

  		/*public function getMarque(){
  			return marqueTable::getMarqueById($this->marque);
  		}*/
	}