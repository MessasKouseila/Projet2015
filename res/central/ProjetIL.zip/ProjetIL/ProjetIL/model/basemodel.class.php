<?php

abstract class basemodel
{

  private $data= array();
  public function __construct($row=null){
    if(is_array($row)  && count($row)>0){
      foreach($row AS $key=>$value){
        $this->$key = $value;
      }
    }
  }

public function __get($key){
      if (array_key_exists($key, $this->data)) {
        return $this->data[$key];
      }
      return null;
    }
    public function __set($key, $value){
      $this->data[$key] = $value;
    }

public function save()
  {
    
    $connection = new dbconnection() ;

    if($this->exist)
    {
      $sql = "update ".get_class($this)." set " ;

      $set = array() ;
      foreach($this->data as $att => $value)
        if($att != 'id' && $value && gettype($value) != "boolean"){
           $set[] = "$att = '".$value."'" ;
        }
      $sql .= implode(",",$set) ;
      $sql .= " where id='".$this->id."'" ;
    }
    else
    {
      $arrayKey = array();
      $arrayValues = array();
      
      foreach(array_keys($this->data) as $array){
        if($array != "exist")
          array_push($arrayKey,$array);
      }

      foreach(array_values($this->data) as $array){
        if(gettype($array) != "boolean")
          array_push($arrayValues,$array);
      }

      //var_dump(array_keys($this->data));
      $sql = "insert into uapv1600543.".get_class($this)." " ;
      $sql .= "(".implode(",",$arrayKey).") " ;
      $sql .= "values ('".implode("','",$arrayValues)."')" ;
    }
    var_dump($sql);
    $connection->doExec($sql) ;
    $id = $connection->getLastInsertId(get_class($this)) ;
    
     
    return $id == false ? NULL : $id ; 
  }

 
}
