<?php

class playerTable {
	public static function getPlayers()
	  {
	    $connection = new dbconnection() ;
	    $sql = "select * from player" ;
	     $res = $connection->doQueryObject( $sql,"player" );
		if($res === false)
	      return false;
		return $res;
	  }

	  public static function getPlayerElo($username)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select elo from player" ;
	     $res = $connection->doQueryObjectOne( $sql,"player" );
		if($res === false)
	      return false;
		return $res;
	  }

	  public static function countPlayers($username)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select COUNT(*) from player where id ='".$username."'" ;
	     $res = $connection->count( $sql );
		if($res === false)
	      return false;
		return $res;
	  }
	  
	  public static function loginPlayer($username,$password)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select * from player where id ='".$username."' and password ='".$password."'" ;
	     $res = $connection->doQueryObjectone( $sql ,"player");
		if($res === false)
	      return false;
		return $res;
	  }

	public static function deleteProfile($username){
	    $connection = new dbconnection() ;
	    $sql = "DELETE FROM player WHERE (id = '".$username."')";
		$res = $connection->doQuery( $sql );
		if($res === false)
	      return false;
		return $res;
	}

	public static function getEloById($username)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select elo from player where id='".$username."'" ;
	     $res = $connection->doQueryObjectOne( $sql,"player" );
		if($res === false)
	      return false;
		return $res;
	  }
}
?>
