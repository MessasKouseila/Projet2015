<?php 
	class server extends basemodel{}?>