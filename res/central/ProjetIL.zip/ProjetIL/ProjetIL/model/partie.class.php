<?php

class partie extends basemodel {}?>
