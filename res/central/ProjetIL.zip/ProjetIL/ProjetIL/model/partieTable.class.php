<?php
class partieTable {
	public static function getStats($username,$date)
	  {
	    $connection = new dbconnection() ;
	    $sql = "select coalesce(sum(gagnee),0) as gagnee,coalesce(sum(perdu),0) as perdue,count(partie.id) as nbrPartie, AVG(classement) from partie where player='".$username."' and to_date(date,'yyyy-mm-dd HH24:MI:SS') <= to_date('".$date."','yyyy-mm-dd HH24:MI:SS');";
	     $res = $connection->doQueryObjectOne( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	  }

	
	public static function getEloByPlayerAndRecentDate($username,$date){
		$connection = new dbconnection() ;
	   // $sql = "select  max(to_date(date,'yyyy-mm-dd HH24:MI:SS')) as date_recente,player,max(elo) as elo  FROM partie where to_date(date,'yyyy-mm-dd HH24:MI:SS')<=to_date('".$date."','yyyy-mm-dd HH24:MI:SS') and player='".$username."' GROUP BY player order by elo desc;";
		 $sql =  $sql = "select max(elo) from partie where player='".$username."' and ABS(to_date('".$date."','yyyy-mm-dd HH24:MI:SS')-to_date(date,'yyyy-mm-dd HH24:MI:SS'))<= all(select ABS(to_date('".$date."','yyyy-mm-dd HH24:MI:SS')-to_date(date,'yyyy-mm-dd HH24:MI:SS')) from partie where player='".$username."') and player='".$username."'"; 		$res = $connection->doQueryObjectOne( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	}

	public static function getEloByDate($date,$username){
		$connection = new dbconnection() ;
	    $sql = "select elo from partie  where date like '".$date."%' and player ='".$username."' group by elo,date having date >= all(select date from partie where date like '".$date."%' and player ='".$username."' group by date);";
	     $res = $connection->doQueryObjectOne( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	}

	public static function getElos($date){
		$connection = new dbconnection() ;
	    //$sql = "select elo from partie where to_date(date,'yyyy-mm-dd HH24:MI:SS') <= to_date('".$date."','yyyy-mm-dd HH24:MI:SS') order by elo desc;";
	    $sql = "select  elo,player,date from partie where TO_date(date,'yyyy-mm-dd HH24:MI:SS') <= TO_date('".$date."','yyyy-mm-dd HH24:MI:SS') GROUP BY player,elo,date  order by date desc;";
	    $res = $connection->doQueryObject( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	}

	public static function getCountPartByPlayer($username){
		$connection = new dbconnection() ;
	    $sql = "select count(*) from partie where player ='".$username."'";
	     $res = $connection->count( $sql );
		if($res === false)
	      return false;
		return $res;
	}

	public static function mostOlderStat($username){
	    $connection = new dbconnection() ;
	    $sql = "select min(date) from partie where player = '".$username."'" ;

	     $res = $connection->doQueryObjectOne( $sql,"server" );
		if($res === false)
	      return false;
		return $res;
	  }

	public static function mostRecentStat($username){
	    $connection = new dbconnection() ;
	    $sql = "select max(date) from partie where player = '".$username."'" ;

	    $res = $connection->doQueryObjectOne( $sql,"server" );
		if($res === false)
	      return false;
		return $res;
	}

	public static function getUsersStats(){
		$connection = new dbconnection() ;
		$sql = "select player.elo, player.id as player, coalesce(sum(gagnee),0) as gagnee, coalesce(sum(perdu),0) as perdue,count(partie.id) as nbrPartie, coalesce(AVG(classement),0) as moyenne from partie right join player on player.id = partie.player group by player.id order by player.elo desc";
		$res = $connection->doQueryObject( $sql,"server" );
		if($res === false)
	      return false;
		return $res;
	}


}
?>
