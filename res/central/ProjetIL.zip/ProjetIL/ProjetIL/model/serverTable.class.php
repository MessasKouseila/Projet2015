<?php

class serverTable {
	public static function getServerNotCompleted(){
	    $connection = new dbconnection() ;
	    $sql = "select server.id,server.port from server left join server_player on server.id = server_player.server where completed=1 and playernumber > (select count(server_player.id) from server_player where server.id = server_player.server) order by updated" ;

	     $res = $connection->doQueryObject( $sql,"server" );
		if($res === false)
	      return false;
		return $res;
	  }

	public static function countServers($id){
	    $connection = new dbconnection() ;
	    $sql = "select COUNT(*) from server where Id ='".$id."'" ;
	     $res = $connection->count( $sql );
		if($res === false)
	      return false;
		return $res;
	}

	public static function deleteServer($ipServer){
	    $connection = new dbconnection() ;
	    $sql = "DELETE FROM server WHERE (id = '".$ipServer."')";
		$res = $connection->doQuery( $sql );
		if($res === false)
	      return false;
		return $res;
	}
}
?>
