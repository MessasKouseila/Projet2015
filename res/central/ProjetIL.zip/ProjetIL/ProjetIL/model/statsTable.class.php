<?php

class statsTable {
	public static function mostOlderStat($username){
	    $connection = new dbconnection() ;
	    $sql = "select min(date) from partie where player = '".$username."'" ;

	     $res = $connection->doQueryObjectOne( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	  }

	public static function mostRecentStat($username){
	    $connection = new dbconnection() ;
	    $sql = "select max(date) from partie where player = '".$username."'" ;

	     $res = $connection->doQueryObjectOne( $sql,"partie" );
		if($res === false)
	      return false;
		return $res;
	  }
}?>
